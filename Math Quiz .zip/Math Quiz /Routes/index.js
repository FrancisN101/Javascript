const express = require('express');
const router = express.Router();
const { leaderboard } = require('../data'); 


router.get('/', (req, res) => {
    res.render('index', { title: 'Math Quiz' });
});


router.post('/quiz/start', (req, res) => {
    const userName = req.body.name;
    req.session.userName = userName; 
    req.session.streak = 0; 
    res.redirect('/quiz'); 
});


router.post('/start', (req, res) => {
    currentUser = req.session.userName; 
    streak = req.session.streak; 
    currentQuestion = generateQuestion(); 
    res.redirect('/quiz');
});

module.exports = router;
