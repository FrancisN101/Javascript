const express = require('express');
const router = express.Router();
const { leaderboard } = require('../data'); 


let streak = 0;
let currentUser = ""; 
let currentQuestion = generateQuestion(); 

function generateQuestion() {
  const num1 = Math.floor(Math.random() * 10) + 1;
  let num2 = Math.floor(Math.random() * 10) + 1;
  const operations = ['+', '-', '*', '/'];
  const randomIndex = Math.floor(Math.random() * operations.length);
  const operation = operations[randomIndex];
  let question;
  let answer;

  switch (operation) {
      case '+':
          question = `${num1} + ${num2}`;
          answer = num1 + num2;
          break;
      case '-':
          if (num1 < num2) {
              [num1, num2] = [num2, num1];
          }
          question = `${num1} - ${num2}`;
          answer = num1 - num2;
          break;
      case '*':
          question = `${num1} * ${num2}`;
          answer = num1 * num2;
          break;
      case '/':
          num2 = Math.floor(Math.random() * num1) + 1;
          while (num1 % num2 !== 0) {
              num2 = Math.floor(Math.random() * num1) + 1;
          }
          question = `${num1} / ${num2}`;
          answer = num1 / num2;
          break;
      default:
          break;
  }

  return { question, answer };
}




router.get('/', (req, res) => {
  res.render('quiz', { title: 'Math Quiz', question: currentQuestion.question });
});


router.post('/answer', (req, res) => {
  const userAnswer = parseInt(req.body.answer);

  if (userAnswer === currentQuestion.answer) {
    streak++;
    currentQuestion = generateQuestion(); // Generate next question
    res.redirect('/quiz');  
  } else {
    console.log("Wrong answer");

    
    leaderboard.push({ name: req.session.userName, streak });  

    streak = 0; 
    res.redirect('/quiz/complete');  
  }
});


router.get('/complete', (req, res) => {
  
  res.render('complete', {
    title: 'Quiz Completed',
    streak: streak,                
    leaderboard: leaderboard,      
    username: req.session.userName 
  });
});


module.exports = router;