const express = require('express');
const router = express.Router();
const { leaderboard } = require('../data'); 


router.get('/', (req, res) => {
  
  const topPlayers = leaderboard.sort((a, b) => b.streak - a.streak).slice(0, 10);
  res.render('leaderboard', { title: 'Leaderboard', leaderboard: topPlayers });
});

module.exports = router;