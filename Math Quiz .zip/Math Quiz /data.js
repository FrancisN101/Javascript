


const leaderboard = [];

module.exports = { leaderboard };